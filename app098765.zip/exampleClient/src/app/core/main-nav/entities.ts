export var Entities: string[] = [
	]

export var AuthEntities: string[] = [
	"user",
	"role",
	"permission",
	"rolepermission",
	"userpermission",
	"userrole",
]

